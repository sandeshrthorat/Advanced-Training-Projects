package evennumber.com;

import java.util.Scanner;

public class EvenNumbers {


		  public static void main(String args[]) {

		
        Scanner sc1=new Scanner(System.in);
        System.out.println("Enter the Number");
        int n = sc1.nextInt();
		System.out.print("Even Numbers from 1 to "+n+" are: ");

		for (int i = 1; i <= n; i++) {

		   //if number%2 == 0 it means its an even number

		   if (i % 2 == 0) {

		 System.out.print(i + " ");

		   }

		}

		  }

		
}
